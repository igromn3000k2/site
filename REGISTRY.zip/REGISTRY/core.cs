using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace RegistryCore
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new RegistryForm());
        }
    }

    public class RegistryForm : Form
    {
        private TreeView treeRegistry;
        private ListView listParams;
        private StatusStrip statusStrip;
        private ToolStripStatusLabel lblStatus;

        private string baseIniPath;
        private string imgPath;
        private FileSystemWatcher watcher;
        private ImageList typeImageList;

        private MenuItem treeCreateFolderMenu;
        private MenuItem treeDeleteFolderMenu;

        private MenuItem listCreateTxtMenu;
        private MenuItem listCreateHexMenu;
        private MenuItem listCreateBinMenu;
        private MenuItem listEditMenu;
        private MenuItem listDeleteMenu;

        public RegistryForm()
        {
            this.KeyPreview = true;
            this.KeyDown += RegistryForm_KeyDown;

            baseIniPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "INI");
            imgPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "IMG");

            if (!Directory.Exists(baseIniPath))
                Directory.CreateDirectory(baseIniPath);

            InitUI();
            LoadAppIcon();
            LoadTypeIcons();

            BuildTree();
            InitFileSystemWatcher();
            UpdateMenuItemsState();
        }

        private void InitUI()
        {
            this.Text = "REGISTRY";
            this.Size = new Size(950, 550);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ShowIcon = true;

            SplitContainer splitContainer = new SplitContainer();
            splitContainer.Dock = DockStyle.Fill;
            splitContainer.SplitterDistance = 260;

            // Дерево разделов
            treeRegistry = new TreeView();
            treeRegistry.Dock = DockStyle.Fill;
            treeRegistry.AfterSelect += TreeRegistry_AfterSelect;
            treeRegistry.MouseClick += TreeRegistry_MouseClick;

            ContextMenu treeMenu = new ContextMenu();
            treeCreateFolderMenu = new MenuItem("Создать раздел", CreateFolder_Click);
            treeDeleteFolderMenu = new MenuItem("Удалить раздел", DeleteFolder_Click);
            treeMenu.MenuItems.Add(treeCreateFolderMenu);
            treeMenu.MenuItems.Add(treeDeleteFolderMenu);
            treeRegistry.ContextMenu = treeMenu;

            // Список параметров
            listParams = new ListView();
            listParams.Dock = DockStyle.Fill;
            listParams.View = View.Details;
            listParams.FullRowSelect = true;
            listParams.GridLines = true;
            listParams.HideSelection = false;
            listParams.SelectedIndexChanged += ListParams_SelectedIndexChanged;
            listParams.MouseClick += ListParams_MouseClick;

            listParams.Columns.Add("NAME", 150);
            listParams.Columns.Add("DATACATEGORY", 130);
            listParams.Columns.Add("DATA (Безлимитно)", 310);
            listParams.Columns.Add("DATEOFCREATE", 150);

            ContextMenu listMenu = new ContextMenu();
            listCreateTxtMenu = new MenuItem("Создать WIN_TXT", (s, e) => CreateParam("WINTXT"));
            listCreateHexMenu = new MenuItem("Создать WIN_HEX", (s, e) => CreateParam("WINHEX"));
            listCreateBinMenu = new MenuItem("Создать WIN_BINARY", (s, e) => CreateParam("WINBINARY"));
            listEditMenu = new MenuItem("Изменить значение", EditParam_Click);
            listDeleteMenu = new MenuItem("Удалить параметр", DeleteParam_Click);

            listMenu.MenuItems.Add(listCreateTxtMenu);
            listMenu.MenuItems.Add(listCreateHexMenu);
            listMenu.MenuItems.Add(listCreateBinMenu);
            listMenu.MenuItems.Add("-");
            listMenu.MenuItems.Add(listEditMenu);
            listMenu.MenuItems.Add(listDeleteMenu);
            listParams.ContextMenu = listMenu;

            splitContainer.Panel1.Controls.Add(treeRegistry);
            splitContainer.Panel2.Controls.Add(listParams);

            statusStrip = new StatusStrip();
            lblStatus = new ToolStripStatusLabel("Нажмите F5 для перезагрузки");
            statusStrip.Items.Add(lblStatus);

            this.Controls.Add(splitContainer);
            this.Controls.Add(statusStrip);
        }

        private void RegistryForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                BuildTree();
                RefreshParamsList();
                lblStatus.Text = "Реестр перезагружен (" + DateTime.Now.ToString("HH:mm:ss") + ")";
            }
        }

        private void LoadAppIcon()
        {
            string iconPng = Path.Combine(imgPath, "icon.png");
            if (File.Exists(iconPng))
            {
                try
                {
                    using (Bitmap bmp = new Bitmap(iconPng))
                    {
                        IntPtr hIcon = bmp.GetHicon();
                        this.Icon = Icon.FromHandle(hIcon);
                    }
                }
                catch { }
            }
        }

        private void LoadTypeIcons()
        {
            typeImageList = new ImageList();
            typeImageList.ImageSize = new Size(16, 16);

            string txtImg = Path.Combine(imgPath, "wintxt.png");
            string hexImg = Path.Combine(imgPath, "winhex.png");
            string binImg = Path.Combine(imgPath, "winbinary.png");
            string unkImg = Path.Combine(imgPath, "winunknown.png");

            if (File.Exists(txtImg))
            {
                typeImageList.Images.Add("WINTXT", Image.FromFile(txtImg));
                typeImageList.Images.Add("WIN_TXT", Image.FromFile(txtImg));
            }
            if (File.Exists(hexImg))
            {
                typeImageList.Images.Add("WINHEX", Image.FromFile(hexImg));
                typeImageList.Images.Add("WIN_HEX", Image.FromFile(hexImg));
                typeImageList.Images.Add("WIN_XEX", Image.FromFile(hexImg));
            }
            if (File.Exists(binImg))
            {
                typeImageList.Images.Add("WINBINARY", Image.FromFile(binImg));
                typeImageList.Images.Add("WIN_BINARY", Image.FromFile(binImg));
                typeImageList.Images.Add("EINBINARY", Image.FromFile(binImg));
            }
            if (File.Exists(unkImg))
            {
                typeImageList.Images.Add("WINUNKNOWN", Image.FromFile(unkImg));
                typeImageList.Images.Add("WIN_UNKNOWN", Image.FromFile(unkImg));
            }

            listParams.SmallImageList = typeImageList;
        }

        private void BuildTree()
        {
            treeRegistry.Nodes.Clear();
            TreeNode rootNode = new TreeNode("REGISTRY");
            rootNode.Tag = baseIniPath;
            treeRegistry.Nodes.Add(rootNode);

            LoadSubDirectories(baseIniPath, rootNode);
            rootNode.Expand();
        }

        private void LoadSubDirectories(string dirPath, TreeNode parentNode)
        {
            try
            {
                foreach (string dir in Directory.GetDirectories(dirPath))
                {
                    DirectoryInfo info = new DirectoryInfo(dir);
                    TreeNode node = new TreeNode(info.Name);
                    node.Tag = dir;
                    parentNode.Nodes.Add(node);
                    LoadSubDirectories(dir, node);
                }
            }
            catch { }
        }

        private void TreeRegistry_AfterSelect(object sender, TreeViewEventArgs e)
        {
            RefreshParamsList();
            UpdateMenuItemsState();
        }

        private void TreeRegistry_MouseClick(object sender, MouseEventArgs e)
        {
            TreeNode node = treeRegistry.GetNodeAt(e.X, e.Y);
            if (node != null)
                treeRegistry.SelectedNode = node;
            UpdateMenuItemsState();
        }

        private void ListParams_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateMenuItemsState();
        }

        private void ListParams_MouseClick(object sender, MouseEventArgs e)
        {
            UpdateMenuItemsState();
        }

        private void UpdateMenuItemsState()
        {
            bool isFolderSelected = (treeRegistry.SelectedNode != null);
            bool isRootSelected = isFolderSelected && ((string)treeRegistry.SelectedNode.Tag == baseIniPath);
            bool isParamSelected = (listParams.SelectedItems.Count > 0);

            treeDeleteFolderMenu.Enabled = isFolderSelected && !isRootSelected;

            bool canCreateParam = isFolderSelected;
            listCreateTxtMenu.Enabled = canCreateParam;
            listCreateHexMenu.Enabled = canCreateParam;
            listCreateBinMenu.Enabled = canCreateParam;

            listEditMenu.Enabled = isParamSelected;
            listDeleteMenu.Enabled = isParamSelected;
        }

        private string NormalizeCategory(string rawCat)
        {
            if (string.IsNullOrEmpty(rawCat)) return "WINUNKNOWN";

            string upper = rawCat.Trim().ToUpper();
            if (upper == "WINTXT" || upper == "WIN_TXT" || upper == "TXT") return "WINTXT";
            if (upper == "WINHEX" || upper == "WIN_HEX" || upper == "WIN_XEX" || upper == "HEX") return "WINHEX";
            if (upper == "WINBINARY" || upper == "WIN_BINARY" || upper == "EINBINARY" || upper == "BINARY") return "WINBINARY";

            return "WINUNKNOWN";
        }

        private void RefreshParamsList()
        {
            if (treeRegistry.SelectedNode == null) return;

            string currentDir = treeRegistry.SelectedNode.Tag as string;
            if (string.IsNullOrEmpty(currentDir) || !Directory.Exists(currentDir)) return;

            listParams.Items.Clear();

            string[] iniFiles = Directory.GetFiles(currentDir, "*.ini");
            foreach (string file in iniFiles)
            {
                string name = Path.GetFileNameWithoutExtension(file);
                string category = "WINUNKNOWN";
                string data = "";
                string dateOfCreate = "";

                try
                {
                    string content = File.ReadAllText(file, Encoding.UTF8);
                    string[] lines = content.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                    foreach (string line in lines)
                    {
                        if (line.StartsWith("NAME=")) name = line.Substring(5);
                        else if (line.StartsWith("DATACATEGORY=")) category = NormalizeCategory(line.Substring(13));
                        else if (line.StartsWith("DATA=")) data = line.Substring(5);
                        else if (line.StartsWith("DATEOFCREATE=")) dateOfCreate = line.Substring(13);
                    }
                }
                catch { }

                ListViewItem item = new ListViewItem(name);
                item.SubItems.Add(category);
                item.SubItems.Add(data);
                item.SubItems.Add(dateOfCreate);
                item.Tag = file;

                if (typeImageList.Images.ContainsKey(category))
                {
                    item.ImageKey = category;
                }

                listParams.Items.Add(item);
            }

            UpdateMenuItemsState();
        }

        private void CreateFolder_Click(object sender, EventArgs e)
        {
            if (treeRegistry.SelectedNode == null) return;
            string parentDir = treeRegistry.SelectedNode.Tag as string;

            string folderName = PromptInput("Создание раздела", "Введите имя нового раздела:", "Новый раздел");
            if (string.IsNullOrEmpty(folderName)) return;

            string fullPath = Path.Combine(parentDir, folderName);
            if (Directory.Exists(fullPath))
            {
                MessageBox.Show("Раздел с таким именем уже существует!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Directory.CreateDirectory(fullPath);
            BuildTree();
        }

        private void DeleteFolder_Click(object sender, EventArgs e)
        {
            if (treeRegistry.SelectedNode == null) return;
            string currentDir = treeRegistry.SelectedNode.Tag as string;

            if (currentDir == baseIniPath) return;

            if (Directory.Exists(currentDir))
            {
                Directory.Delete(currentDir, true);
                BuildTree();
            }
        }

        private void CreateParam(string category)
        {
            if (treeRegistry.SelectedNode == null) return;
            string currentDir = treeRegistry.SelectedNode.Tag as string;

            string paramName = PromptInput("Создание параметра", "Введите имя параметра:", "REGISTERTEST");
            if (string.IsNullOrEmpty(paramName)) return;

            string filePath = Path.Combine(currentDir, paramName + ".ini");
            if (File.Exists(filePath))
            {
                MessageBox.Show("Параметр с таким именем уже существует!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DateTime now = DateTime.Now;
            string exactDateStr = now.ToString("dd.MM.yyyy HH:mm:ss");

            string initialData = "0";
            if (category == "WINHEX") initialData = "01 01 11 00 00 00 00 00 2A 2A 1B";
            else if (category == "WINBINARY") initialData = "00000000 00000001";

            using (StreamWriter sw = new StreamWriter(filePath, false, new UTF8Encoding(false)))
            {
                sw.WriteLine("[{REGISTERINIFILE}]");
                sw.WriteLine("NAME=" + paramName);
                sw.WriteLine("DATACATEGORY=" + category);
                sw.WriteLine("DATA=" + initialData);
                sw.WriteLine("DATEOFCREATE=" + exactDateStr);
            }

            File.SetCreationTime(filePath, now);
            File.SetLastWriteTime(filePath, now);

            RefreshParamsList();
        }

        private void DeleteParam_Click(object sender, EventArgs e)
        {
            if (listParams.SelectedItems.Count == 0) return;

            ListViewItem item = listParams.SelectedItems[0];
            string filePath = item.Tag as string;

            if (File.Exists(filePath))
            {
                File.Delete(filePath);
                RefreshParamsList();
            }
        }

        private void EditParam_Click(object sender, EventArgs e)
        {
            if (listParams.SelectedItems.Count == 0) return;

            ListViewItem item = listParams.SelectedItems[0];
            string filePath = item.Tag as string;
            string paramName = item.Text;
            string category = item.SubItems[1].Text;
            string currentVal = item.SubItems[2].Text;
            string dateOfCreate = item.SubItems[3].Text;

            Form editForm = new Form
            {
                Text = "Изменить значение",
                Size = new Size(500, 220),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false
            };

            TextBox txtInput = new TextBox
            {
                Text = currentVal,
                Left = 15,
                Top = 15,
                Width = 450,
                Height = 90,
                Multiline = true,
                MaxLength = 0,
                ScrollBars = ScrollBars.Vertical
            };

            Button btnSave = new Button
            {
                Text = "Сохранить",
                Left = 360,
                Top = 120,
                DialogResult = DialogResult.OK
            };

            editForm.Controls.Add(txtInput);
            editForm.Controls.Add(btnSave);

            if (editForm.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = new StreamWriter(filePath, false, new UTF8Encoding(false)))
                {
                    sw.WriteLine("[{REGISTERINIFILE}]");
                    sw.WriteLine("NAME=" + paramName);
                    sw.WriteLine("DATACATEGORY=" + category);
                    sw.WriteLine("DATA=" + txtInput.Text);
                    sw.WriteLine("DATEOFCREATE=" + dateOfCreate);
                }

                RefreshParamsList();
            }
        }

        private string PromptInput(string title, string promptText, string defaultValue)
        {
            Form prompt = new Form()
            {
                Width = 400,
                Height = 160,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = title,
                StartPosition = FormStartPosition.CenterParent,
                MaximizeBox = false,
                MinimizeBox = false
            };
            Label textLabel = new Label() { Left = 15, Top = 15, Text = promptText, AutoSize = true };
            TextBox textBox = new TextBox() { Left = 15, Top = 40, Width = 350, Text = defaultValue };
            Button confirmation = new Button() { Text = "ОК", Left = 265, Width = 100, Top = 75, DialogResult = DialogResult.OK };
            prompt.Controls.Add(textBox);
            prompt.Controls.Add(confirmation);
            prompt.Controls.Add(textLabel);
            prompt.AcceptButton = confirmation;

            return prompt.ShowDialog() == DialogResult.OK ? textBox.Text.Trim() : "";
        }

        private void InitFileSystemWatcher()
        {
            watcher = new FileSystemWatcher(baseIniPath);
            watcher.IncludeSubdirectories = true;
            watcher.NotifyFilter = NotifyFilters.DirectoryName | NotifyFilters.FileName | NotifyFilters.LastWrite;

            watcher.Changed += OnFileSystemChanged;
            watcher.Created += OnFileSystemChanged;
            watcher.Deleted += OnFileSystemChanged;
            watcher.Renamed += OnFileSystemChanged;

            watcher.EnableRaisingEvents = true;
        }

        private void OnFileSystemChanged(object sender, FileSystemEventArgs e)
        {
            this.BeginInvoke((MethodInvoker)delegate
            {
                BuildTree();
                RefreshParamsList();
            });
        }
    }
}